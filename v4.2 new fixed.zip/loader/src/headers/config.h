#pragma once

#define HTTP_SERVER "185.252.178.48"
#define HTTP_PORT 80

#define TFTP_SERVER "185.252.178.48"
